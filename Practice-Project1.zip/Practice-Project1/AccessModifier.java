
class MyClass {
    // Public field
    public int publicField = 10;

    // Private method
    private void privateMethod() {
        System.out.println("Private method called");
    }
}

public class AccessModifier {
    public static void main(String[] args) {
        MyClass myObject = new MyClass();

        // Accessing public field
        System.out.println("Public Field Value: " + myObject.publicField);

        
    }
}
