class Outer {
    private int outerVar = 10;

    // Inner class
    class Inner {
        void display() {
            System.out.println("Inner class accessing outerVar: " + outerVar);
        }
    }
}

public class InnerClass {
    public static void main(String[] args) {
        Outer outerObj = new Outer();
        Outer.Inner innerObj = outerObj.new Inner();

        // Accessing inner class method
        innerObj.display();
    }
}
