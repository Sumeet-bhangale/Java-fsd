public class ArraysExp {
    public static void main(String[] args) {
        // Creating and initializing an array
        int[] numbers = {1, 2, 3, 4, 5};

        // Accessing array elements
        System.out.println("Array Elements:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
    }
}
