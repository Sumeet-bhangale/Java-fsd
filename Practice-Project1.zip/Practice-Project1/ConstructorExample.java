class Car {
    String brand;
    int year;

    // Default constructor
    Car() {
        brand = "Unknown";
        year = 0;
    }

    // Parameterized constructor
    Car(String brand, int year) {
        this.brand = brand;
        this.year = year;
    }
}

public class ConstructorExample {
    public static void main(String[] args) {
        // Using default constructor
        Car defaultCar = new Car();
        System.out.println("Default Car: " + defaultCar.brand + " " + defaultCar.year);

        // Using parameterized constructor
        Car paramCar = new Car("Toyota", 2022);
        System.out.println("Parameterized Car: " + paramCar.brand + " " + paramCar.year);
    }
}
