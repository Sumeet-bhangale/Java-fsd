import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExp {
    public static void main(String[] args) {
        // Creating a regular expression pattern
        String regex = "[a-zA-Z]+";

        // Creating a String to be matched
        String input = "Hello123 Java";

        // Creating a Pattern object
        Pattern pattern = Pattern.compile(regex);

        // Creating a Matcher object
        Matcher matcher = pattern.matcher(input);

        // Checking for matches
        while (matcher.find()) {
            System.out.println("Match found: " + matcher.group());
        }
    }
}
