public class StringConversion {
    public static void main(String[] args) {
        // Creating a String
        String str = "Hello, World!";

        // Converting String to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);
        System.out.println("StringBuffer: " + stringBuffer);

        // Converting String to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(str);
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
