class MathOperations {
    int add(int a, int b) {
        return a + b;
    }
}

public class MethodExample {
    public static void main(String[] args) {
        MathOperations mathObj = new MathOperations();

        // Calling a method and verifying its implementation
        int sum = mathObj.add(5, 7);
        System.out.println("Sum: " + sum);
    }
}
