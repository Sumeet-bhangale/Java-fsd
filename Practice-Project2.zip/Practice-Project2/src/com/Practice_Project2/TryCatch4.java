package com.Practice_Project2;
 



import java.util.Scanner;

public class TryCatch4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a number: ");

        try {
            int number = Integer.parseInt(scanner.nextLine());
            System.out.println("Entered number: " + number);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid integer.");
        } finally {
            System.out.println("This block will always be executed.");
            scanner.close();
        }
    }
}

