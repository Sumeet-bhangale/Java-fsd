package com.Practice_Project2;





class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionHandling5 {
    public static void main(String[] args) {
        try {
            throwExample();
            throwsExample();
        } catch (CustomException e) {
            System.out.println("Caught custom exception: " + e.getMessage());
        } finally {
            System.out.println("This block will always be executed.");
        }
    }

    static void throwExample() throws CustomException {
        throw new CustomException("This is a custom exception thrown using throw.");
    }

    static void throwsExample() throws CustomException {
        throw new CustomException("This is a custom exception thrown using throws.");
    }
}
