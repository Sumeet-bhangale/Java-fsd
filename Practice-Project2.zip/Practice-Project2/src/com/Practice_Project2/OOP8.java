package com.Practice_Project2;

//Class definition
class Circle {
 // Instance variables
 private double radius;

 // Constructor
 public Circle(double radius) {
     this.radius = radius;
 }

 // Method to calculate area
 public double calculateArea() {
     return Math.PI * radius * radius;
 }
}

public class OOP8 {
 public static void main(String[] args) {
     // Creating an object of the Circle class
     Circle myCircle = new Circle(5.0);

     // Accessing class members through the object
     double area = myCircle.calculateArea();
     System.out.println("Area of the circle: " + area);
 }
}

