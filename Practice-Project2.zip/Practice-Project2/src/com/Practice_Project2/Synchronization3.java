package com.Practice_Project2;



class CounterManager  {
    private int count = 0;

    // Synchronized method
    public synchronized void increment() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " Count: " + count++);
            try {
                Thread.sleep(100); // Simulate some work
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class CounterThread extends Thread {
    private CounterManager  sharedResource;

    CounterThread(CounterManager  sharedResource, String name) {
        super(name);
        this.sharedResource = sharedResource;
    }

    public void run() {
        sharedResource.increment();
    }
}

public class Synchronization3 {
    public static void main(String[] args) {
    	CounterManager  sharedResource = new CounterManager ();

        // Two threads sharing the same resource
        Thread thread1 = new CounterThread(sharedResource, "Thread 1");
        Thread thread2 = new CounterThread(sharedResource, "Thread 2");

        // Start the threads
        thread1.start();
        thread2.start();
    }
}
