package com.Practice_Project2;





import java.util.Scanner;

public class ExceptionHandling6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter two numbers:");

        try {
            int num1 = Integer.parseInt(scanner.nextLine());
            int num2 = Integer.parseInt(scanner.nextLine());

            int result = divideNumbers(num1, num2);
            System.out.println("Result of division: " + result);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter valid integers.");
        } catch (ArithmeticException e) {
            System.out.println("Cannot divide by zero. Please enter a non-zero divisor.");
        } finally {
            System.out.println("This block will always be executed.");
            scanner.close();
        }
    }

    static int divideNumbers(int dividend, int divisor) {
        if (divisor == 0) {
            throw new ArithmeticException("Cannot divide by zero.");
        }
        return dividend / divisor;
    }
}
