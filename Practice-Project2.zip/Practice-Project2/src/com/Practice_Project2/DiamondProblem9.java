package com.Practice_Project2;

//Interface definition
interface A {
 default void display() {
     System.out.println("Interface A");
 }
}

//Interface definition
interface B extends A {
 default void display() {
     System.out.println("Interface B");
 }
}

//Class implementing interfaces A and B
class C implements B, A {
 // Resolving the diamond problem by providing its own implementation
	
 @Override
 public void display() {
   //  A.super.display(); // Choose implementation from interface A
     B.super.display(); // Choose implementation from interface B
     System.out.println("Class C");
 }
}

public class DiamondProblem9 {
 public static void main(String[] args) {
     C myObject = new C();
     myObject.display();
 }
}

