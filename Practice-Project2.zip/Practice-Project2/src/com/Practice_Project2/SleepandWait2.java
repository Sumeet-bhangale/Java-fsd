package com.Practice_Project2;



class SharedResource {
    boolean flag = false;
    
    synchronized void printNumbers() {
        for (int i = 1; i <= 5; i++) {
            while (!flag) {
                try {
                    wait(); // Release the lock and wait for notification
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println(Thread.currentThread().getName() + ": " + i);
            flag = false;
            notify(); // Notify the waiting thread (if any)
        }
    }
}

class NumberPrinter extends Thread {
    SharedResource sharedResource;

    NumberPrinter(SharedResource sharedResource, String name) {
        super(name);
        this.sharedResource = sharedResource;
    }

    public void run() {
        sharedResource.printNumbers();
    }
}

public class SleepandWait2 {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();

        Thread t1 = new NumberPrinter(sharedResource, "Thread 1");
        Thread t2 = new NumberPrinter(sharedResource, "Thread 2");

        t1.start();
        t2.start();

        try {
            // Sleep for 1 second in the main thread
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        synchronized (sharedResource) {
            sharedResource.flag = true;
            sharedResource.notify(); // Notify one of the waiting threads
        }
    }
}
