package com.example;

import java.io.Serializable;

public class ExampleBean implements Serializable {
    private String property;

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }
}
