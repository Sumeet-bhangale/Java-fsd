

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LocatingElementsthroughCSSandXPath {
    public static void main(String[] args) {
        // Set the path of the GeckoDriver executable
        System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");

        // Create a new instance of the Firefox driver
        WebDriver driver = new FirefoxDriver();

        
        
     // Open Eclipse and set up your Selenium project

     // Using Tag and ID
     WebElement emailElement = driver.findElement(By.cssSelector("input#email"));

     // Using Tag and Class
     WebElement inputTextElement = driver.findElement(By.cssSelector("input.inputtext"));

     // Using Tag and Attribute
     WebElement lastNameElement = driver.findElement(By.cssSelector("input[name='lastName']"));

     // Using Tag, Class, and Attribute
     WebElement tabIndexElement = driver.findElement(By.cssSelector("input.inputtext[tabindex='1']"));

     // Using Inner Text (not widely supported)
     WebElement bostonElement = driver.findElement(By.cssSelector("font:contains('Boston')"));

     // Absolute XPath
     WebElement absoluteXPathElement = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/h4[1]/b"));

     // Relative XPath
     WebElement relativeXPathElement = driver.findElement(By.xpath("//*[@class='relativexapath']"));

    }
}
