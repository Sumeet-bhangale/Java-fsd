import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingVariousWebElements {
public static void main(String[] args) {
	 WebDriver driver = new FirefoxDriver();

	 
	 WebElement editBox = driver.findElement(By.id("editBoxId"));
	 editBox.sendKeys("Enter Value"); // Enter a value
	 editBox.clear(); // Clear the value
	 boolean isEnabled = editBox.isEnabled(); // Check enabled status
	 boolean isDisplayed = editBox.isDisplayed(); // Check edit box existence
	 String value = editBox.getAttribute("value"); // Get the value

	 
	 WebElement link = driver.findElement(By.linkText("Link Text"));
	 link.click(); // Click link
	 boolean isLinkDisplayed = link.isDisplayed(); // Check the link existence
	 boolean isLinkEnabled = link.isEnabled(); // Check the link enabled status
	 String linkName = link.getText(); // Return the link name

	 
	 WebElement button = driver.findElement(By.id("buttonId"));
	 button.click(); // Click
	 boolean isButtonEnabled = button.isEnabled(); // Check enabled status
	 boolean isButtonDisplayed = button.isDisplayed(); // Display status

	 
	 WebElement image = driver.findElement(By.id("imageId")); // General image
	 WebElement imageButton = driver.findElement(By.id("imageButtonId")); // Image button
	 WebElement imageLink = driver.findElement(By.id("imageLinkId")); // Image link
	 imageButton.click(); // Clicks image button
	 imageLink.click(); // Clicks image link

	 
	 WebElement textArea = driver.findElement(By.id("textAreaId"));
	 String text = textArea.getText(); // Return/capture text area or error message

	 
	 WebElement checkbox = driver.findElement(By.id("checkboxId"));
	 boolean isCheckboxDisplayed = checkbox.isDisplayed(); // Check if displayed
	 boolean isCheckboxEnabled = checkbox.isEnabled(); // Check if enabled
	 boolean isCheckboxSelected = checkbox.isSelected(); // Check if selected
	 checkbox.click(); // Select the checkbox (toggle state)

	 
	 List<WebElement> radioButtons = driver.findElements(By.name("radioButtonName"));
	 radioButtons.get(1).click(); // Select radio button
	 boolean isRadioButtonDisplayed = radioButtons.get(1).isDisplayed(); // Verify display status
	 boolean isRadioButtonEnabled = radioButtons.get(1).isEnabled(); // Verify enabled status
	 boolean isRadioButtonSelected = radioButtons.get(1).isSelected(); // Verify selected status

	 
	 Select dropdown = new Select(driver.findElement(By.id("dropdownId")));
	 dropdown.selectByVisibleText("Banana"); // Select by visible text
	 dropdown.selectByIndex(1); // Select by index
	 int itemCount = dropdown.getOptions().size(); // Items count

	 
	 WebElement table = driver.findElement(By.id("tableId"));
	 int rowsCount = table.findElements(By.tagName("tr")).size(); // Rows count
	 int cellsCount = table.findElements(By.tagName("td")).size(); // Cells count

	 
	 driver.switchTo().frame("iframe1"); // Switch to a frame
	// Perform operations inside the frame
	driver.switchTo().defaultContent(); // Switch back to the top window

	
	// Open a new tab
	((JavascriptExecutor)driver).executeScript("window.open()");
	ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
	// Switch to the new tab
	driver.switchTo().window(tabs.get(1));
	// Perform operations in the new tab
	// Switch back to the original tab
	driver.switchTo().window(tabs.get(0));

}
}
