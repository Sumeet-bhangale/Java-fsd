import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Locator {
public static void main(String[] args) {
	
	
	
	WebElement element = driver.findElement(By.id("Email"));
	
	WebElement element1 = driver.findElement(By.name("name"));
	
	
	// Find a web element using the Link Text locator
	WebElement element2 = driver.findElement(By.linkText("LinkText"));
	// For partial link text, use:
	WebElement element3 = driver.findElement(By.partialLinkText("PartOfLinkText"));

	
	// Find a web element using a Relative XPath
	WebElement element4 = driver.findElement(By.xpath("//*[@class='relativexapath']"));

	// Find a web element using an Absolute XPath
	WebElement element5 = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/h4[1]/b"));

	
	// Find a web element using a Tag and ID CSS Selector
	WebElement element6 = driver.findElement(By.cssSelector("input#email"));

	// Find a web element using a Tag and Class CSS Selector
	WebElement element7 = driver.findElement(By.cssSelector("input.inputtext"));

	// Find a web element using a Tag and Attribute CSS Selector
	WebElement element8 = driver.findElement(By.cssSelector("input[name='lastName']"));

	// Find a web element using a Tag, Class, and Attribute CSS Selector
	WebElement element9 = driver.findElement(By.cssSelector("input.inputtext[tabindex='1']"));

	// Find a web element using an Inner Text CSS Selector (not widely supported)
	WebElement element = driver.findElement(By.cssSelector("font:contains('Boston')"));

	
	// Find a web element using the contains() function
	WebElement element10 = driver.findElement(By.xpath("//*[contains(text(),'sub')]"));

	// Find a web element using the OR & AND operators
	WebElement element11 = driver.findElement(By.xpath("//*[@type='submit' or @name='btnReset']"));

	// Find a web element using the starts-with() function
	WebElement element12 = driver.findElement(By.xpath("//label[starts-with(@id,'message')]"));

	// Find a web element using the text() function
	WebElement element13 = driver.findElement(By.xpath("//td[text()='UserID']"));

	// Find a web element using the following axis
	WebElement element14 = driver.findElement(By.xpath("//*[@type='text']//following::input"));

	// Find a web element using the preceding axis
	WebElement element15 = driver.findElement(By.xpath("//*[@type='text']//preceding::input"));

	// Find a web element using the following-sibling axis
	WebElement element16 = driver.findElement(By.xpath("//*[@type='text']//following-sibling::input"));

}
}
