

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Alert;

public class ExternalElements {
    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        // Initialize the WebDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to a website that has pop-ups, new tabs, or new windows for testing
        driver.get("https://example.com");

        // Step 1.5.1: Handling External Pop-ups
        // To click on 'OK' button in pop-up
        driver.switchTo().alert().accept();

        // To click on 'Cancel' button in pop-up
        driver.switchTo().alert().dismiss();

        // To capture the alert message
        String alertMessage = driver.switchTo().alert().getText();
        System.out.println("Alert Message: " + alertMessage);

        // To enter information into the alert
        driver.switchTo().alert().sendKeys("text");

        // Note: There is no `close()` method for alerts. Use `accept()` or `dismiss()` to close an alert.

        // Step 1.5.2: Handling New Tabs and New Windows
        // Opening a new tab
        driver.findElement(By.tagName("body")).sendKeys(Keys.CONTROL + "t");

        // Opening a new window
        driver.findElement(By.tagName("body")).sendKeys(Keys.CONTROL + "n");

        // Close the browser
        driver.quit();
    }
}
