package com.HandlingUserAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSpringBoot7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
