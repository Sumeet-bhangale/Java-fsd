package com.HandlingUserAuthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheckboxApplication.class, args);
	}

}
