package com.HandlingUserAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckboxApplicationTests {

	@Test
	void contextLoads() {
	}

}
