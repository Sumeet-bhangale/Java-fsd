import java.util.Arrays;

public class FourthSmallestElement2 {

    public static void main(String[] args) {
        int[] unsortedList = {12, 5, 3, 8, 15, 7, 9, 10};
        int fourthSmallest = findFourthSmallest(unsortedList);

        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }

    static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("Array size is less than 4");
            return -1; // Not enough elements in the array
        }

        Arrays.sort(arr);
        return arr[3];
    }
}
