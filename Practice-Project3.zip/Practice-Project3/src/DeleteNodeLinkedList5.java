class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class DeleteNodeLinkedList5 {

    static Node head;

    public static void main(String[] args) {
        // Example linked list: 1 -> 2 -> 3 -> 4 -> 5
        head = new Node(1);
        head.next = new Node(2);
        head.next.next = new Node(3);
        head.next.next.next = new Node(4);
        head.next.next.next.next = new Node(5);

        int keyToDelete = 3;
        deleteNode(keyToDelete);

        // Display the modified linked list
        printLinkedList();
    }

    static void deleteNode(int key) {
        Node temp = head;
        Node prev = null;

        // If the key is in the head node
        if (temp != null && temp.data == key) {
            head = temp.next;
            return;
        }

        // Search for the key to be deleted, keep track of the previous node
        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

        // If the key is not present
        if (temp == null)
            return;

        // Unlink the node from the linked list
        prev.next = temp.next;
    }

    static void printLinkedList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
    }
}
