public class SumInRange3 {

    public static void main(String[] args) {
        int[] array = {1, 3, 5, 7, 9, 11, 13, 15}; // Example array
        int n = array.length;
        int L = 2;
        int R = 5;

        int sumInRange = findSumInRange(array, n, L, R);

        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sumInRange);
    }

    static int findSumInRange(int[] arr, int n, int L, int R) {
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range");
            return -1; // Invalid range
        }

        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }
}
