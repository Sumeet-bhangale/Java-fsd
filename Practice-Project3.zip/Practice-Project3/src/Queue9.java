import java.util.LinkedList;
import java.util.Queue;

public class Queue9 {

    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue elements into the queue
        queue.offer(1);
        queue.offer(2);
        queue.offer(3);

        // Display the queue
        System.out.println("Queue after enqueue: " + queue);

        // Dequeue an element from the queue
        int dequeuedElement = queue.poll();
        System.out.println("Dequeued element: " + dequeuedElement);

        // Display the queue after dequeue
        System.out.println("Queue after dequeue: " + queue);
    }
}
