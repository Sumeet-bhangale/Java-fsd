import java.util.Arrays;

public class RightRotateArray1 {

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9}; // Example array

        System.out.println("Original Array: " + Arrays.toString(array));

        int rotationSteps = 5;
        rightRotateArray(array, rotationSteps);

        System.out.println("Array after right rotation by " + rotationSteps + " steps: " + Arrays.toString(array));
    }

    static void rightRotateArray(int[] arr, int steps) {
        int length = arr.length;

        // Calculate the effective number of rotation steps
        int effectiveSteps = steps % length;

        // Create a temporary array to store the rotated elements
        int[] temp = new int[effectiveSteps];

        // Copy the last 'effectiveSteps' elements to the temporary array
        System.arraycopy(arr, length - effectiveSteps, temp, 0, effectiveSteps);

        // Shift the remaining elements to the right
        System.arraycopy(arr, 0, arr, effectiveSteps, length - effectiveSteps);

        // Copy back the elements from the temporary array to the beginning of the array
        System.arraycopy(temp, 0, arr, 0, effectiveSteps);
    }
}
