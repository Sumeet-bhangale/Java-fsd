class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class InsertSortedCircularLinkedList6 {

    static Node head;

    public static void main(String[] args) {
        // Example circular linked list: 1 -> 2 -> 4 -> 5 (sorted)
        head = new Node(1);
        head.next = new Node(2);
        head.next.next = new Node(4);
        head.next.next.next = new Node(5);
        head.next.next.next.next = head; // Making it circular

        int newData = 3;
        insertSorted(newData);

        // Display the modified circular linked list
        printCircularLinkedList();
    }

    static void insertSorted(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            // If the list is empty, make the new node the head and point to itself
            head = newNode;
            newNode.next = head;
        } else if (newData <= head.data) {
            // If the new data is less than or equal to the head data, insert at the beginning
            newNode.next = head;
            head = newNode;
        } else {
            // Traverse the list to find the appropriate position to insert the new node
            Node temp = head;
            while (temp.next != head && temp.next.data < newData) {
                temp = temp.next;
            }

            // Insert the new node in the middle or at the end
            newNode.next = temp.next;
            temp.next = newNode;
        }
    }

    static void printCircularLinkedList() {
        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
    }
}
